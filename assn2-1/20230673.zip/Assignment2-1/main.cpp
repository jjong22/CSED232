#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <cctype>

using namespace std;

struct Pokemon // 포켓몬 자료의 구조체
{
    int number;
    string name;
    string type[2];
    int height;
    float weight;
    string pre_evo;
    string post_evo;
};

int search_pockemon(Pokemon[], int, string); // 포켓몬의 이름으로 검색하여 그 index를 반환하는 함수
int search_pre_evo_pockemon(Pokemon[], int, string);  // pre_evo로 검색하여 그 index를 반환하는 함수
int search_post_evo_pockemon(Pokemon[], int, string); // post_evo로 검색하여 그 index를 반환하는 함수
void add_pockemon(Pokemon[], int&); // database에 포켓몬을 추가하는 함수
void edit_pockemon(Pokemon[], int&); // database에 있는 포켓몬을 수정하는 함수
void delete_pokemon(Pokemon[], int&); // database에 있는 포켓몬을 삭제하는 함수
void print_specific_pokemon(Pokemon[], int); // 특정 포켓몬을 출력하는 함수
void print_all_pokemon(Pokemon[], int); // 모든 포켓몬을 출력하는 함수
void print_with_type(Pokemon[], int); // 특정 타입의 포켓몬을 출력하는 함수
void print_menu(); // 메뉴를 출력하는 함수
int get_data_from_file(Pokemon[]); // 파일에서 데이터를 읽어오는 함수
void save_data_to_file(Pokemon[], int); // 데이터를 파일에 저장하는 함수
void init_database(Pokemon[]); // 데이터베이스를 초기화하는 함수

int main()
{
    Pokemon database[20]; // 데이터 베이스
    init_database(database);

    int num_of_pokemons = get_data_from_file(database); // 데이터 베이스를 파일에서 읽어옴.

    while (1)
    {
        print_menu();

        string input_selection;
        int selection;
        cout << "Select a menu: ";
        cin >> input_selection;

        try // 문자열로 입력을 받고, int 형으로 convert
        {
            selection = stoi(input_selection);
        }
        catch (const std::exception& e) // 잘 못된 입력이 들어온 경우 무시하고 다시 입력 받음
        {
            continue;
        }

        if (selection == 1) // 특정 포켓몬을 출력하는 경우
        {
            if (num_of_pokemons == 0) // 데이터 베이스에 포켓몬이 없을때
            {
                cout << "There is no Pokemon in the database." << endl;
                continue;
            }

            string name;
            cout << "Enter the name of Pokemon to display: ";
            cin >> name;
            int idx = search_pockemon(database, num_of_pokemons, name);

            if (idx == -1) // 데이터 베이스에 해당 포켓몬이 없을때
            {
                cout << "The entered name doesn’t exist in this database." << endl;
                continue;
            }

            print_specific_pokemon(database, idx);
        }
        else if (selection == 2) // 포켓몬을 추가할 때
        {
            add_pockemon(database, num_of_pokemons);
        }
        else if (selection == 3) // 포켓몬을 수정할 때
        {
            edit_pockemon(database, num_of_pokemons);
        }
        else if (selection == 4) // 포켓몬을 삭제할 때
        {
            delete_pokemon(database, num_of_pokemons);
        }
        else if (selection == 5) // 포켓몬을 조건에 따라 출력할 때
        {
            while (1)
            {
                string input_subselection;
                int subselection;

                cout << "1: Display All     2: Display by Type" << endl;
                cout << "Select the output format: ";
                cin >> input_subselection;

                try
                {
                    subselection = stoi(input_subselection); // string to int
                }
                catch (const std::exception& e)
                {
                    continue;
                }


                if (subselection == 1) // 데이터 베이스의 모든 포켓몬을 출력
                {
                    print_all_pokemon(database, num_of_pokemons);
                    break;
                }
                else if (subselection == 2) // 특정 타입의 포켓몬만 출력
                {
                    print_with_type(database, num_of_pokemons);
                    break;
                }
            }
        }
        else if (selection == 6) // 프로그램 종료 후 데이터 베이스 파일로 저장
        {
            cout << "The database has been saved in \"db.txt\"" << endl;
            save_data_to_file(database, num_of_pokemons);
            break;
        }
    }

    return 0;
}

void add_pockemon(Pokemon database[], int& num_of_pokemons) // database에 포켓몬을 추가하는 함수
{
    string temp_evo;
    string temp_name;

    database[num_of_pokemons].number = num_of_pokemons + 1; // 포켓몬의 번호

    while (1)
    {
        cout << "Enter the name of the Pockemon to add: ";
        cin >> temp_name;

        if (temp_name.length() > 10) // 이름의 길이가 10를 넘어가는 경우
        {
            cout << "Invalid input. Please enter again." << endl;
            continue;
        }

        break;
    }


    if (search_pockemon(database, num_of_pokemons, temp_name) != -1) // 이미 존재하는 이름의 포켓몬인 경우
    {
        cout << "The entered name already exists in this database." << endl;
        return;
    }

    while (1)
    {
        string temp_type1 = "";
        string temp_type2 = "";

        cout << "Enter the type(s): ";
        cin >> temp_type1;
        if (cin.peek() != '\n') // 콤마가 있는 경우
        {
            temp_type1.erase(temp_type1.size() - 1);
            cin >> temp_type2;
        }

        if (temp_type1.length() > 8 or temp_type2.length() > 8) // type의 길이가 8을 넘어가는 경우
        {
            cout << "Invalid input. Please enter again." << endl;
            continue;
        }

        if (cin.peek() != '\n') // 2개보다 많은 입력
        {
            cout << "Invalid input. Please enter again." << endl;
            cin.ignore(256, '\n');
            continue;
        }
        else
        {
            database[num_of_pokemons].type[0] = temp_type1;
            database[num_of_pokemons].type[1] = temp_type2;
            break;
        }
    }


    while (1)
    {
        cout << "Enter the height (cm): ";
        string input_height;
        int temp_height;
        cin >> input_height;


        try { temp_height = stoi(input_height); }
        catch (exception e) { cout << "Invalid input. Please enter again." << endl; continue; }

        if (temp_height < 1 or temp_height > 9999) { cout << "Invalid input. Please enter again." << endl; continue; }

        database[num_of_pokemons].height = temp_height;

        break;
    }


    while (1)
    {
        cout << "Enter the weight (kg): ";
        string input_weight;
        float temp_weight;
        cin >> input_weight;

        try { temp_weight = stof(input_weight); }
        catch (exception e) { cout << "Invalid input. Please enter again." << endl; continue; }
        if (temp_weight < 0.1 or temp_weight > 999.9) { cout << "Invalid input. Please enter again." << endl; continue; }

        database[num_of_pokemons].weight = temp_weight;

        break;
    }

    while (1)
    {
        cout << "Enter the name of the pre-evolution Pockemon (Type \"-\" if none): ";
        cin >> temp_evo;

        if (temp_evo == "-") // pre-evo가 없는 경우 "-" 입력
        {
            database[num_of_pokemons].pre_evo = temp_evo;
            break;
        }
        int temp_evo_idx = search_pockemon(database, num_of_pokemons, temp_evo);

        if (temp_evo_idx == -1) // 이 이름의 포켓몬이 존재하지 않는 경우。
        {
            cout << "The entered name doesn’t exist in this database." << endl;
            continue;
        }
        else
        {
            if (database[temp_evo_idx].post_evo != "-") // prev_evo가 이미 post_evo를 가지고 있는 경우
            {
                cout << "The entered name already has a post-evolution." << endl;
                continue;
            }
            else // 정상적인 입력
            {
                database[num_of_pokemons].pre_evo = temp_evo;
                database[search_pockemon(database, num_of_pokemons, temp_evo)].post_evo = temp_name;
                break;
            }
        }
    }
    database[num_of_pokemons].name = temp_name; // prev_evo에 자신의 이름이 입력되는 경우를 방지를 위해 뒤에서 저장

    print_specific_pokemon(database, num_of_pokemons);

    num_of_pokemons++;
}

void edit_pockemon(Pokemon database[], int& num_of_pokemons) // database에 있는 포켓몬을 수정하는 함수
{
    if (num_of_pokemons == 0) // 도감에 포켓몬이 하나도 없는 경우 예외 처리
    {
        cout << "There is no Pokemon in the database." << endl;
        return;
    }

    string pokemon_name;
    cout << "Enter the name of the Pokemon to edit: ";
    cin >> pokemon_name;

    int result = search_pockemon(database, num_of_pokemons, pokemon_name);
    if (result == -1) // 포켓몬이 데이터 베이스에 없는 경우 예외 처리
    {
        cout << "The entered name doesn’t exist in this database." << endl;
        return;
    }

    print_specific_pokemon(database, result);
    Pokemon temp_pokemon = database[result];
    int selection;

    while (1)
    {
        string input_selection;
        cout << "1. Type    2. Height    3. Weight    4. Pre-Evolution" << endl;
        cout << "Enter the attribute to edit: ";
        cin >> input_selection;

        try
        {
            selection = stoi(input_selection); // string to int
        }
        catch (const std::exception& e)
        {
            continue;
        }

        if ((selection < 1) or (selection > 4)) // 범위를 벗어나는 경우
        {
            cout << "Invalid input. Please enter again." << endl;
            continue;
        }

        break;
    }

    if (selection == 1) // Type
    {
        while (1)
        {
            string temp_type1 = "";
            string temp_type2 = "";

            cout << "Enter the type(s): ";
            cin >> temp_type1;

            if (cin.peek() != '\n') // 콤마가 있는 경우
            {
                temp_type1.erase(temp_type1.size() - 1);
                cin >> temp_type2;
            }

            if (temp_type1.length() > 8 or temp_type2.length() > 8) // type의 길이가 8을 넘어가는 경우
            {
                cout << "Invalid input. Please enter again." << endl;
                continue;
            }

            if (cin.peek() != '\n') // 2개보다 많은 입력
            {
                cout << "Invalid input. Please enter again." << endl;
                cin.ignore(256, '\n');
                continue;
            }

            temp_pokemon.type[0] = temp_type1;
            temp_pokemon.type[1] = temp_type2;
            break;
        }
    }
    else if (selection == 2) // Height
    {
        while (1)
        {
            cout << "Enter the height (cm): ";

            string input_height;
            int temp_height;
            cin >> input_height;

            try { temp_height = stoi(input_height); } // string to int
            catch (exception e) { cout << "Invalid input. Please enter again." << endl; continue; } // int로 변환할 수 없는 경우
            if (temp_height < 1 or temp_height > 9999) { cout << "Invalid input. Please enter again." << endl; continue; } // 범위를 벗어나는 경우

            temp_pokemon.height = temp_height;

            break;
        }
    }
    else if (selection == 3) // Weight
    {
        while (1)
        {
            cout << "Enter the Weight (kg): ";

            string input_weight;
            float temp_weight;
            cin >> input_weight;

            try { temp_weight = stof(input_weight); } // string to float
            catch (exception e) { cout << "Invalid input. Please enter again." << endl; continue; } // float로 변환할 수 없는 경우
            if (temp_weight < 0.1 or temp_weight > 999.9) { cout << "Invalid input. Please enter again." << endl; continue; } // 범위를 벗어나는 경우

            temp_pokemon.weight = temp_weight;

            break;
        }
    }
    else if (selection == 4)
    {
        while (1)
        {
            string input_new_prev_evo; // 새로운 pre-evolution의 이름
            int new_prev_evo_index; // 새로운 pre-evolution의 index

            cout << "Enter the name of the pre-evolution Pockemon (Type \"-\" if none): ";
            cin >> input_new_prev_evo;

            if (input_new_prev_evo == "-") // pre-evo를 지우는 경우
            {
                int temp_post_evo_index = search_post_evo_pockemon(database, num_of_pokemons, database[result].name);
                temp_pokemon.pre_evo = "-";
                if (temp_post_evo_index != -1)
                {
                    database[temp_post_evo_index].post_evo = "-";
                }
                break;
            }

            if (input_new_prev_evo == database[result].pre_evo) // 이전의 입력과 같은 경우
            {
                break;
            }

            new_prev_evo_index = search_pockemon(database, num_of_pokemons, input_new_prev_evo); // 데이터 베이스에서의 new_prev_evo의 index
            if (new_prev_evo_index == -1) // 이 이름의 포켓몬이 존재하지 않는 경우
            {
                cout << "The entered name doesn’t exist in this database." << endl;
                continue;
            }

            int result_pre_evo_index = search_pockemon(database, num_of_pokemons, database[result].pre_evo); // result의 pre_evo
            int result_post_evo_index = search_pockemon(database, num_of_pokemons, database[result].post_evo); // result의 post_evo
            int new_prev_prev_evo_index = search_pockemon(database, num_of_pokemons, database[new_prev_evo_index].pre_evo); // new_prev_prev_evo

            if (new_prev_evo_index == result) // 자기 자신을 pre_evo로 설정하는 경우
            {
                cout << "The entered name is the same as the Pokemon to edit." << endl;
                continue;
            }
            // 예외 1. 이전 pre_evo가 post_evo를 가지고 있는 경우
            if (search_pockemon(database, num_of_pokemons, database[new_prev_evo_index].post_evo) != -1)
            {
                cout << "The entered name already has a post-evolution." << endl;
                continue;
            }
            // 예외 2. 순환하는 경우 1. post == new_prev_evo 2. post == new_prev_prev_evo 3. post->post == new_prev_evo 4. post->post == new_prev_prev_evo
            if (result_post_evo_index != -1 and new_prev_prev_evo_index != -1)
            {
                if ((result_post_evo_index == new_prev_evo_index) or (search_pockemon(database, num_of_pokemons, database[result_post_evo_index].post_evo) == new_prev_evo_index) or (search_pockemon(database, num_of_pokemons, database[result_post_evo_index].post_evo) == new_prev_prev_evo_index))
                {
                    cout << "cycle detected!!" << endl;
                    continue;
                }
            }

            if (result_pre_evo_index != -1) { database[result_pre_evo_index].post_evo = "-"; }
            temp_pokemon.pre_evo = input_new_prev_evo;
            database[new_prev_evo_index].post_evo = temp_pokemon.name;
            break;
        }
    }
    database[result] = temp_pokemon; // 수정된 정보를 저장

    print_specific_pokemon(database, result);
}

int search_pockemon(Pokemon database[], int num_of_pokemons, string name) // 포켓몬의 이름으로 검색하여 그 index를 반환하는 함수
{
    for (int i = 0; i < num_of_pokemons; i++)
    {
        if (database[i].name == name)
        {
            return i; // database에서의 index를 반환
        }
    }
    return -1; // 찾지 못한 경우, -1을 반환
}

int search_pre_evo_pockemon(Pokemon database[], int num_of_pokemons, string name) // 포켓몬의 이름으로 검색하여, 이 이름을 pre_evo로 가지고 있는 포켓몬의 index를 반환하는 함수
{
    for (int i = 0; i < num_of_pokemons; i++)
    {
        if (database[i].pre_evo == name)
        {
            return i; // database에서의 index를 반환
        }
    }
    return -1; // 찾지 못한 경우, -1을 반환
}

int search_post_evo_pockemon(Pokemon database[], int num_of_pokemons, string name) // 포켓몬의 이름으로 검색하여, 이 이름을 post_evo로 가지고 있는 포켓몬의 index를 반환하는 함수
{
    for (int i = 0; i < num_of_pokemons; i++)
    {
        if (database[i].post_evo == name)
        {
            return i; // database에서의 index를 반환
        }
    }
    return -1; // 찾지 못한 경우, -1을 반환
}

void delete_pokemon(Pokemon database[], int& num_of_pokemons) // database에 있는 포켓몬을 삭제하는 함수
{
    if (num_of_pokemons == 0) // 데이터 베이스에 포켓몬이 없을 때, 예외 처리
    {
        cout << "There is no Pokemon in the database." << endl;
        return;
    }

    string pokemon_name;
    cout << "Enter the name of the Pokemon to delete: ";
    cin >> pokemon_name;

    int result = search_pockemon(database, num_of_pokemons, pokemon_name);

    if (result == -1) // 해당 이름의 포켓몬이 데이터 베이스에 없는 경우, 예외 처리
    {
        cout << "The entered name doesn’t exist in this database." << endl;
        return;
    }

    int have_pre_evo = search_pre_evo_pockemon(database, num_of_pokemons, pokemon_name); // name을 pre_evo로 가지고 있는 포켓몬
    int have_post_evo = search_post_evo_pockemon(database, num_of_pokemons, pokemon_name); // name을 post_evo로 가지고 있는 포켓몬

    if (have_pre_evo != -1)
    {
        database[have_pre_evo].pre_evo = "-";
    }
    if (have_post_evo != -1)
    {
        database[have_post_evo].post_evo = "-";
    }

    for (int i = result; i < num_of_pokemons - 1; i++) // 한칸씩 땡기기
    {
        database[i] = database[i + 1];
        database[i].number -= 1;
    }

    num_of_pokemons -= 1;
}

void print_specific_pokemon(Pokemon database[], int i) // 특정 idx의 포켓몬을 출력하는 함수
{
    cout << "-------------------------------------------------------------------------" << endl;
    cout.width(10);
    cout << left << "Number";
    cout.width(15);
    cout << left << "Name";
    cout.width(15);
    cout << left << "Type";
    cout.width(10);
    cout << left << "Height";
    cout.width(10);
    cout << left << "Weight";
    cout.width(20);
    cout << left << "Pre-evo";
    cout.width(20);
    cout << left << "Post-evo" << endl;

    string temp;
    if (database[i].type[1] != "") { temp = database[i].type[0] + ", " + database[i].type[1]; } // type이 2개인 경우
    else { temp = database[i].type[0]; } // type이 1개인 경우

    cout.width(10);
    cout << left << database[i].number;
    cout.width(15);
    cout << left << database[i].name;
    cout.width(15);
    cout << left << temp;
    cout.width(10);
    cout << left << to_string(database[i].height) + "cm";
    cout.width(10);
    string weight = to_string(database[i].weight);
    cout << left << weight.erase(weight.size() - 5) + "kg"; // 소수점 이하 1자리까지만 출력
    cout.width(20);
    cout << left << database[i].pre_evo;
    cout.width(20);
    cout << left << database[i].post_evo << endl;
    cout << "-------------------------------------------------------------------------" << endl;
}

void print_all_pokemon(Pokemon database[], int num_of_pokemons) // 모든 포켓몬을 출력하는 함수
{
    cout << "-------------------------------------------------------------------------" << endl;
    cout.width(10);
    cout << left << "Number";
    cout.width(15);
    cout << left << "Name";
    cout.width(15);
    cout << left << "Type";
    cout.width(10);
    cout << left << "Height";
    cout.width(10);
    cout << left << "Weight";
    cout.width(20);
    cout << left << "Pre-evo";
    cout.width(20);
    cout << left << "Post-evo" << endl;
    for (int i = 0; i < num_of_pokemons; i++)
    {
        string temp;
        if (database[i].type[1] != "") { temp = database[i].type[0] + ", " + database[i].type[1]; } // type이 2개인 경우
        else { temp = database[i].type[0]; } // type이 1개인 경우

        cout.width(10);
        cout << left << database[i].number;
        cout.width(15);
        cout << left << database[i].name;
        cout.width(15);
        cout << left << temp;
        cout.width(10);
        cout << left << to_string(database[i].height) + "cm";
        cout.width(10);
        string weight = to_string(database[i].weight);
        cout << left << weight.erase(weight.size() - 5) + "kg"; // 소수점 이하 1자리까지만 출력
        cout.width(20);
        cout << left << database[i].pre_evo;
        cout.width(20);
        cout << left << database[i].post_evo << endl;
    }
    cout << "-------------------------------------------------------------------------" << endl;
}

void print_with_type(Pokemon database[], int num_of_pokemons)
{
    string input_type;
    cout << "Enter the type to display: ";
    cin >> input_type;

    cout << "-------------------------------------------------------------------------" << endl;
    cout.width(10);
    cout << left << "Number";
    cout.width(15);
    cout << left << "Name";
    cout.width(15);
    cout << left << "Type";
    cout.width(10);
    cout << left << "Height";
    cout.width(10);
    cout << left << "Weight";
    cout.width(20);
    cout << left << "Pre-evo";
    cout.width(20);
    cout << left << "Post-evo" << endl;
    for (int i = 0; i < num_of_pokemons; i++)
    {
        if ((database[i].type[0] == input_type) or (database[i].type[1] == input_type))
        {
            string temp;
            if (database[i].type[1] != "")
            {
                if (database[i].type[0] == input_type) // 찾는 타입이 앞에 있는 경우
                {
                    temp = database[i].type[0] + ", " + database[i].type[1];
                }
                else // 찾는 타입이 뒤에 있는 경우
                {
                    temp = database[i].type[1] + ", " + database[i].type[0];
                }
            }
            else { temp = database[i].type[0]; }

            cout.width(10);
            cout << left << database[i].number;
            cout.width(15);
            cout << left << database[i].name;
            cout.width(15);
            cout << left << temp;
            cout.width(10);
            cout << left << to_string(database[i].height) + "cm";
            cout.width(10);
            string weight = to_string(database[i].weight);
            cout << left << weight.erase(weight.size() - 5) + "kg";
            cout.width(20);
            cout << left << database[i].pre_evo;
            cout.width(20);
            cout << left << database[i].post_evo << endl;
        }
    }
    cout << "-------------------------------------------------------------------------" << endl;
}

void print_menu() // 메뉴 출력
{
    cout << "================MENU===============" << endl;
    cout << "1. Display Pokemon" << endl;
    cout << "2. Add Pokemon" << endl;
    cout << "3. Edit Pokemon" << endl;
    cout << "4. Delete a Pokemon" << endl;
    cout << "5. Display Database" << endl;
    cout << "6. Exit" << endl;
    cout << "===================================" << endl;
}

int get_data_from_file(Pokemon database[]) // "db.txt" 파일에서 데이터를 읽어오는 함수s
{
    std::ifstream inputFile("db.txt");
    if (!inputFile) {
        std::cerr << "데이터 베이스가 없습니다." << std::endl;
        return 0;
    }

    int i = 0; // 데이터 베이스에 저장된 포켓몬 종류의 수
    int number;
    string name;
    string type[2];
    int height;
    float weight;
    string pre_evo;
    string post_evo;

    while (inputFile)
    {
        Pokemon temp_pokemon;

        inputFile >> temp_pokemon.number;

        if (!inputFile) { break; } // eof를 만나면 종료

        inputFile >> temp_pokemon.name;
        inputFile >> temp_pokemon.type[0];
        if (temp_pokemon.type[0].back() == ',') // 콤마가 있는 경우
        {
            temp_pokemon.type[0].erase(temp_pokemon.type[0].size() - 1);
            inputFile >> temp_pokemon.type[1];
        }
        inputFile >> temp_pokemon.height;
        inputFile >> temp_pokemon.weight;
        inputFile >> temp_pokemon.pre_evo;
        inputFile >> temp_pokemon.post_evo;

        database[i] = temp_pokemon;
        i++;
    }
    inputFile.close();

    return i;
}

void save_data_to_file(Pokemon database[], int num_of_pokemons) // 데이터를 파일에 저장하는 함수
{
    std::ofstream outputFile("db.txt");

    for (int i = 0; i < num_of_pokemons; i++)
    {
        outputFile << database[i].number << " ";
        outputFile << database[i].name << " ";
        outputFile << database[i].type[0];
        if (database[i].type[1] != "")
        {
            outputFile << ", " << database[i].type[1];
        }
        outputFile << " ";
        outputFile << database[i].height << " ";
        outputFile << database[i].weight << " ";
        outputFile << database[i].pre_evo << " ";
        outputFile << database[i].post_evo;

        if (i != num_of_pokemons - 1)
        {
            outputFile << endl;
        }
    }
    outputFile.close();
}

void init_database(Pokemon database[]) // 데이터베이스를 초기화하는 함수
{
    for (int i = 0; i < 20; i++)
    {
        database[i].number = 0;
        database[i].name = "";
        database[i].type[0] = "";
        database[i].type[1] = "";
        database[i].height = 0;
        database[i].weight = 0;
        database[i].pre_evo = "-";
        database[i].post_evo = "-";
    }
}