#include <iostream>
#include <string>
#include <chrono>
#include <cstdlib>
#include <conio.h>
#include <random>
#include <vector>
#include <deque>
#include <thread>
#include <algorithm>

#include "Setting.h"
#include "Map.h"
#include "Utils.h"
#include "Object.h"

using namespace std;

int main()
{
    int user_input; // get user's input

    Setting setting;
    Setting* setting_ptr = &setting; // address of setting

    while (1)
    {
        system("cls");
        print_MainMenu();
        cout << "Enter" << endl;
        cin >> user_input;

        if (user_input == 1) // start game
        {
            start_game(setting_ptr);

        }
        else if (user_input == 2) // setting
        {
            setting_game(setting_ptr);
        }
        else if (user_input == 3) // exit
        {
            return 0;
        }
    }

    return 0;
}