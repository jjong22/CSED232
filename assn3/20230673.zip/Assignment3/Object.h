#ifndef OBJECT_H
#define OBJECT_H

class Object {
private:
    int pos_x;
    int pos_y;
    int object_type;
public:
    enum obj { EMPTY = 0, FOOD = 1, COIN = 2, PLAYER = 3, ENEMY = 4, WALL = 5 };
    int get_pos_x();
    int get_pos_y();
    int get_object_type();
    void set_pos_x(int pos_x);
    void set_pos_y(int pos_y);
    void set_object_type(int object_type);
    Object();
    Object(int pos_x, int pos_y, int object_type);
    virtual ~Object();
    virtual char get_object_shape() = 0;
};

class Player : public Object
{
public:
    Player();
    Player(int pos_x, int pos_y);
    ~Player();
    char get_object_shape();
};

class Enemy : public Object
{
public:
    Enemy();
    Enemy(int pos_x, int pos_y);
    ~Enemy();
    char get_object_shape();
};

class Food : public Object
{
public:
    Food();
    Food(int pos_x, int pos_y);
    ~Food();
    char get_object_shape();
};

class Coin : public Object
{
public:
    Coin();
    Coin(int pos_x, int pos_y);
    ~Coin();
    char get_object_shape();
};

class Wall : public Object
{
public:
    Wall();
    Wall(int pos_x, int pos_y);
    ~Wall();
    char get_object_shape();
};

class Empty : public Object
{
public:
    Empty();
    Empty(int pos_x, int pos_y);
    ~Empty();
    char get_object_shape();
};

#endif