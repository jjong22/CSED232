#ifndef SETTING_H
#define SETTING_H

class Setting
{
private:
    int map_size_x;
    int map_size_y;
    int player_life_count;
    int enemy_snake_length;
    int hard_mod;

public:
    Setting();
    Setting(int x, int y, int life_count, int snake_length, int level);
    void set_map_size(int x, int y); // set map size
    void set_player_life_count(int life_count); // set player life count
    void set_enemy_snake_length(int length); // set enemy snake length
    void set_hard_mod(int level); // set if hardmode.

    int get_map_size_x();
    int get_map_size_y();
    int get_player_life_count();
    int get_enemy_snake_length();
    int get_hard_mod();

    virtual bool is_movable(int x, int y);
};

int setting_game(Setting* setting);

#endif