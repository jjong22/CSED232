#include <iostream>

#include "Setting.h"
#include "Utils.h"

using namespace std;

void Setting::set_map_size(int x, int y) // set map size by setting.
{
    map_size_x = x;
    map_size_y = y;
}

void Setting::set_player_life_count(int life_count) // set player's life count by setting
{
    player_life_count = life_count;
}

void Setting::set_enemy_snake_length(int length) // set enemy snake's length by setting
{
    enemy_snake_length = length;
}

void Setting::set_hard_mod(int level) // set if hardmode.
{
    hard_mod = level;
}

Setting::Setting() // default mode in game.
{
    map_size_x = 60;
    map_size_y = 40;
    player_life_count = 3;
    enemy_snake_length = 3;
    hard_mod = 0;
}

Setting::Setting(int x, int y, int life_count, int snake_length, int level) // update setting with new parameter. This will be inherited to Map class.
{
    map_size_x = x;
    map_size_y = y;
    player_life_count = life_count;
    enemy_snake_length = snake_length;
    hard_mod = level;
}

int Setting::get_map_size_x() { return map_size_x; } // return max x size.
int Setting::get_map_size_y() { return map_size_y; } // return max y size.
int Setting::get_player_life_count() { return player_life_count; } // return player's life count.
int Setting::get_enemy_snake_length() { return enemy_snake_length; } // return enemy's snake length.
int Setting::get_hard_mod() { return hard_mod; } // return if hardmode.

int setting_game(Setting* setting) // setting mode
{
    int user_input;
    int map_size_x;
    int map_size_y;
    int player_life_count;
    int enemy_snake_length;
    int hard_mod;

    system("cls"); // clear terminal.

    while (1)
    {
        print_SettingMenu();
        cout << "Enter number." << endl;
        cin >> user_input;

        if (user_input == 1) // setting the map size.
        {
            while (1) 
            {
                cout << "Enter map size x (20 - 100)" << endl;
                cin >> map_size_x;
                if (map_size_x < 20 or map_size_x > 100)
                {
                    cout << "invaild map size." << endl;
                    continue;
                }
                break;
            }

            while (1)
            {
                cout << "Enter map size y (20 - 100)" << endl;
                cin >> map_size_y;
                if (map_size_y < 20 or map_size_y > 100)
                {
                    cout << "invaild map size." << endl;
                    continue;
                }
                break;
            }
            setting->set_map_size(map_size_x, map_size_y);
        }

        else if (user_input == 2) // setting the player life count.
        {
            while (1)
            {
                cout << "Enter player life count (1 - 10)" << endl;
                cin >> player_life_count;

                if (player_life_count < 1 or player_life_count > 10)
                {
                    cout << "invaild player life count." << endl;
                    continue;
                }

                setting->set_player_life_count(player_life_count);
                break;

            }
        }

        else if (user_input == 3) // setting the Enemy snake length.
        {
            while (1)
            {
                cout << "Enter Enemy Snake Length (1 - 10)" << endl;
                cin >> enemy_snake_length;

                if (enemy_snake_length < 1 or enemy_snake_length > 10)
                {
                    cout << "invaild length." << endl;
                    continue;
                }

                setting->set_enemy_snake_length(enemy_snake_length);
                break;

            }
        }
        else if (user_input == 4) // setting if goes to hardmode.
        {
            while (1)
            {
                cout << "If you want to go in a hard mod, enter 1. If not, enter 0." << endl;
                cin >> hard_mod;

                if (hard_mod != 0 and hard_mod != 1)
                {
                    cout << "invaild input." << endl;
                    continue;
                }

                setting->set_hard_mod(hard_mod);
                break;
            }
        }
        else if (user_input == 5) // return to main
        {
            return 0;
        }
    }
}

bool Setting::is_movable(int x, int y) // base function
{
    return true;
}