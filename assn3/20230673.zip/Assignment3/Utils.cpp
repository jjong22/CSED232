#include <iostream>
#include <random>
#include <deque>
#include <algorithm>
#include <chrono>
#include <conio.h>
#include <iomanip>

#include "Utils.h"
#include "Setting.h"
#include "Map.h"

using namespace std;

enum User_key_input { UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3 };

int start_game(Setting* setting) // the function of manipulate getchar and time. And gives those to map class.
{
    Map main_map(*setting); // make map with setting.

    system("cls"); // clear terminal.
    main_map.print_map();

    int game_result = 0; // of result is -1, game is over.
    chrono::system_clock::time_point start = chrono::system_clock::now(); // save time of game start.
    char temp_key = ' ';

    while (1)
    {
        if (_kbhit()) { // if new key is inputed,
            char get_user_keyinput = _getch(); // getkey with _getch().
            if (get_user_keyinput == 'w' and temp_key != 's') { game_result = main_map.update_map(UP); temp_key = get_user_keyinput; } // move to up
            else if (get_user_keyinput == 's' and temp_key != 'w') { game_result = main_map.update_map(DOWN); temp_key = get_user_keyinput; } // move to down
            else if (get_user_keyinput == 'a' and temp_key != 'd') { game_result = main_map.update_map(LEFT); temp_key = get_user_keyinput; } // move to left
            else if (get_user_keyinput == 'd' and temp_key != 'a') { game_result = main_map.update_map(RIGHT); temp_key = get_user_keyinput; } // move to right
            else if (get_user_keyinput == ' ') { game_result = -1; }
            else { continue; }

            if (game_result == -1) // game over
            {
                system("cls");
                break;
            }

            chrono::duration<double>sec = chrono::system_clock::now() - start;
            cout << "time : " << int(sec.count()) << 's' << endl; // calculate time pass, and print it.
            cout << endl;
        }
    }

    // end screen
    int user_input;
    chrono::duration<double>sec = chrono::system_clock::now() - start;
    int total_time = int( sec.count() );

    print_end_game(total_time, main_map.get_coin_score());
    while (1)
    {
        cout << "Enter" << endl;
        cin >> user_input;

        if (user_input == 1) // return to main.
        {
            break;
        }
        else if (user_input == 2) // restart game.
        {
            start_game(setting);
        }
        else if (user_input == 3) // exit
        {
            exit(0);
        }
    }

    return 0;
}

void print_MainMenu() // print infomation of main manu
{
    cout << "############################################################" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                        Main Menu                       ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                     1. Game Start                      ##" << endl;
    cout << "##                     2. Setting                         ##" << endl;
    cout << "##                     3. Exit                            ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "############################################################" << endl;
}

void print_SettingMenu() // print infomation of setting menu.
{
    cout << "############################################################" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                     Setting Menu                       ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                  1. Map Size                           ##" << endl;
    cout << "##                  2. Life                               ##" << endl;
    cout << "##                  3. Enemy Snake Length                 ##" << endl;
    cout << "##                  4. Hard mode                          ##" << endl;
    cout << "##                  5. Back to Main Menu                  ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "############################################################" << endl;
}

void print_end_game(int total_time, int coin_score) // print infomation of end game.
{
    cout << "############################################################" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##               -------- Result ---------                ##" << endl;
    cout << "##                 Play Time: " << setw(4) << right << total_time << 's' << "                       ##" << endl;
    cout << "##                  Score : " << setw(4) << right << coin_score << "                          ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                  1. Back to Main Menu                  ##" << endl;
    cout << "##                  2. Restart                            ##" << endl;
    cout << "##                  3. Exit                               ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "##                                                        ##" << endl;
    cout << "############################################################" << endl;


}