#include "Object.h"

Object::Object(int pos_x, int pos_y, int object_type = EMPTY)
{
    this->pos_x = pos_x;
    this->pos_y = pos_y;
    this->object_type = object_type;
}

Object::Object()
{
    this->pos_x = 0;
    this->pos_y = 0;
    this->object_type = EMPTY;
}

Object::~Object()
{
    ;
}

int Object::get_pos_x()
{
    return pos_x;
}

int Object::get_pos_y()
{
    return pos_y;
}

int Object::get_object_type()
{
    return object_type;
}

void Object::set_pos_x(int pos_x)
{
    this->pos_x = pos_x;
}

void Object::set_pos_y(int pos_y)
{
    this->pos_y = pos_y;
}

void Object::set_object_type(int object_type)
{
    this->object_type = object_type;
}

Player::Player()
{
    ;
}

Enemy::Enemy()
{
    ;
}

Food::Food()
{
    ;
}

Coin::Coin()
{
    ;
}

Wall::Wall()
{
    ;
}

Empty::Empty()
{
    ;
}

Player::Player(int pos_x, int pos_y) : Object(pos_x, pos_y)
{
    set_object_type(PLAYER);
}

Player::~Player()
{
    ;
}

Enemy::Enemy(int pos_x, int pos_y) : Object(pos_x, pos_y)
{
    set_object_type(ENEMY);
}

Enemy::~Enemy()
{
    ;
}

Food::Food(int pos_x, int pos_y) : Object(pos_x, pos_y)
{
    set_object_type(FOOD);
}

Food::~Food()
{
    ;
}

Coin::Coin(int pos_x, int pos_y) : Object(pos_x, pos_y)
{
    set_object_type(COIN);
}

Coin::~Coin()
{
    ;
}

Wall::Wall(int pos_x, int pos_y) : Object(pos_x, pos_y)
{
    set_object_type(WALL);
}

Wall::~Wall()
{
    ;
}

Empty::Empty(int pos_x, int pos_y) : Object(pos_x, pos_y)
{
    set_object_type(EMPTY);
}

Empty::~Empty()
{
    ;
}

char Player::get_object_shape()
{
    return '*';
}

char Enemy::get_object_shape()
{
    return '@';
}

char Food::get_object_shape()
{
    return '^';
}

char Coin::get_object_shape()
{
    return '$';
}

char Wall::get_object_shape()
{
    return '#';
}

char Empty::get_object_shape()
{
    return ' ';
}
