#include <iostream>
#include <random>
#include <deque>
#include <algorithm>

#include "Setting.h"
#include "Map.h"

using namespace std;

enum User_key_input { UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3 };

random_device rd; 
mt19937 mersenne(rd()); // random setting from <random> module.

Map::Map(Setting &setting) : Setting(setting) // inherited by Setting class.
{
    player_max_life_count = this->get_player_life_count();
    player_snake_length = 1;

    uniform_int_distribution<> rand_x(1, this->get_map_size_x() - 2); 
    uniform_int_distribution<> rand_y(1, this->get_map_size_y() - 2); // random number in game map range.

    for (int i = 0; i < this->get_map_size_y(); i++)
    {
        for (int j = 0; j < this->get_map_size_x(); j++)
        {
            if (i == 0 or i == this->get_map_size_y() - 1 or j == 0 or j == this->get_map_size_x() - 1)
            {
                map_arr[i][j] = WALL; // set outline to wall.
            }
        }
    }

    player_head_pos_x = rand_x(mersenne);
    player_head_pos_y = rand_y(mersenne); // get random number

    map_arr[player_head_pos_y][player_head_pos_x] = PLAYER;

    player_pos_x_set.push_back(player_head_pos_x);
    player_pos_y_set.push_back(player_head_pos_y); // store player's pos in deque array.

    while (1)
    {
        enemy_head_pos_x = rand_x(mersenne);
        enemy_head_pos_y = rand_y(mersenne); // get random number

        if ((enemy_head_pos_x == player_head_pos_x) and (enemy_head_pos_y == player_head_pos_y)) { continue; } // start place cant be same.
        else {
            map_arr[enemy_head_pos_y][enemy_head_pos_x] = ENEMY;

            enemy_head_pos_x_set.push_back(enemy_head_pos_x);
            enemy_head_pos_y_set.push_back(enemy_head_pos_y); // store enemy's pos in deque array.
            break;
        }
    }

    while (1)
    {
        food_pos_x = rand_x(mersenne);
        food_pos_y = rand_y(mersenne); // get random number

        if ((food_pos_x == player_head_pos_x) and (food_pos_x == player_head_pos_y)) { continue; }
        else if ((food_pos_x == enemy_head_pos_x) and (food_pos_y == enemy_head_pos_y)) { continue; } // start place cant be same.
        else {
            map_arr[food_pos_y][food_pos_x] = FOOD;
            break;
        }
    }

    for (int i = 0; i < 10; i++)
    {
        int coin_x = rand_x(mersenne);
        int coin_y = rand_y(mersenne); // get random number

        if ((coin_x == player_head_pos_x) and (coin_y == player_head_pos_y)) { continue; }
        else if ((coin_x == enemy_head_pos_x) and (coin_y == enemy_head_pos_y)) { continue; }
        else if ((coin_x == food_pos_x) and (coin_y == food_pos_y)) { continue; } // start place cant be same.
        else {
            if ((find(coin_pos_x_set.begin(), coin_pos_x_set.end(), coin_x) != coin_pos_x_set.end()) and
                (find(coin_pos_y_set.begin(), coin_pos_y_set.end(), coin_x) != coin_pos_y_set.end())) {
                continue;
            } // start place also cant be same to coin itself.

            map_arr[coin_y][coin_x] = COIN;
            coin_pos_x_set.push_back(coin_x);
            coin_pos_y_set.push_back(coin_y); // store coin's pos in vector array.
        }
    } 

    this->coin_score = 0;
}

void Map::print_map() // print all infomation of map.
{
    system("cls"); // clear terminal

    for (int i = 0; i < this->enemy_head_pos_x_set.size(); i++)
    {
        map_arr[enemy_head_pos_y_set[i]][enemy_head_pos_x_set[i]] = ENEMY; // enemy is prior to items
    }

    for (int i = 0; i < this->get_map_size_y(); i++)
    {
        for (int j = 0; j < this->get_map_size_x(); j++)
        {
            if (map_arr[i][j] == EMPTY) { cout << "  "; }
            else if (map_arr[i][j] == WALL) { cout << "##"; }
            else if (map_arr[i][j] == FOOD) { cout << " ^"; }
            else if (map_arr[i][j] == COIN) { cout << " $"; }
            else if (map_arr[i][j] == PLAYER) { cout << " *"; }
            else if (map_arr[i][j] == ENEMY) { cout << " @"; }
        }
        cout << endl;
    }

    cout << "Score : " << coin_score << endl;
    cout << "Player Life : " << get_player_life_count() << " / " << player_max_life_count << endl;

    map_arr[food_pos_y][food_pos_x] = FOOD;

    for (int i = 0; i < coin_pos_x_set.size(); i++)
    {
        map_arr[coin_pos_y_set[i]][coin_pos_x_set[i]] = COIN;
    }
    // map_arr can be overwrite by player or enemy,
    // so we should update from saved pos_x and pos_y.
}

int Map::update_map(int user_input)
{
    // update player move
    uniform_int_distribution<> rand_x(1, this->get_map_size_x() - 2);
    uniform_int_distribution<> rand_y(1, this->get_map_size_y() - 2);

    if (user_input == UP) { player_head_pos_y -= 1; }
    else if (user_input == DOWN) { player_head_pos_y += 1; }
    else if (user_input == LEFT) { player_head_pos_x -= 1; }
    else if (user_input == RIGHT) { player_head_pos_x += 1; }

    int next_direction_obj = map_arr[player_head_pos_y][player_head_pos_x];

    if (next_direction_obj == WALL or next_direction_obj == ENEMY or next_direction_obj == PLAYER) // cant move, life - 1
    {
        this->set_player_life_count(this->get_player_life_count() - 1); // life - 1
        player_snake_length = 1;
        if (this->get_player_life_count() == 0) { system("cls"); return -1; }

        while (1)
        {
            player_head_pos_x = rand_x(mersenne);
            player_head_pos_y = rand_y(mersenne);

            if (map_arr[player_head_pos_y][player_head_pos_x] == EMPTY)
            {
                map_arr[player_head_pos_y][player_head_pos_x] = PLAYER; // place player in random place.
                break;
            }
        }

        for (int i = 0; i < player_pos_x_set.size(); i++)
        {
            map_arr[player_pos_y_set[i]][player_pos_x_set[i]] = EMPTY; // clear tails in map.
        }

        player_pos_x_set.clear();
        player_pos_y_set.clear();
    }
    else if (next_direction_obj == COIN) // when next direction is coin.
    {
        coin_score += 1;

        int cnt = 0;
        while (1)
        {
            int temp_x = coin_pos_x_set[cnt];
            int temp_y = coin_pos_y_set[cnt];

            if (temp_x == player_head_pos_x and temp_y == player_head_pos_y) // erase coin in coin_set
            {
                coin_pos_x_set.erase(coin_pos_x_set.begin() + cnt);
                coin_pos_y_set.erase(coin_pos_y_set.begin() + cnt);

                break;
            }

            cnt += 1;
        }
    }
    else if (next_direction_obj == FOOD) { // when next direction is food.
        player_snake_length += 1;

        while (1)
        {
            food_pos_x = rand_x(mersenne);
            food_pos_y = rand_y(mersenne);

            if (map_arr[food_pos_y][food_pos_x] == EMPTY)
            {
                map_arr[food_pos_y][food_pos_x] = FOOD; // place food in random place.
                break;
            }
        }
    }

    map_arr[player_head_pos_y][player_head_pos_x] = PLAYER; // move to map_arr where (next_direction) is pointed.

    player_pos_x_set.push_back(player_head_pos_x); // add player's move
    player_pos_y_set.push_back(player_head_pos_y);

    if (player_snake_length < player_pos_x_set.size()) // erase when snake is move.
    {
        int tail_x = player_pos_x_set.front();
        int tail_y = player_pos_y_set.front();
        map_arr[tail_y][tail_x] = EMPTY;
        player_pos_x_set.pop_front();
        player_pos_y_set.pop_front();
    }

    // update enemy snake's move
    bool is_enemy_not_movable = !(is_movable(enemy_head_pos_x, enemy_head_pos_y)); // when enemy snake cant move, it goes to random place in map.

    while (1)
    {
        if (is_enemy_not_movable)
        {
            while (1)
            {
                enemy_head_pos_x = rand_x(mersenne);
                enemy_head_pos_y = rand_y(mersenne);

                if (map_arr[enemy_head_pos_y][enemy_head_pos_x] == EMPTY)
                {
                    map_arr[enemy_head_pos_y][enemy_head_pos_x] = ENEMY;
                    break;
                }
            }

            for (int i = 0; i < enemy_head_pos_x_set.size(); i++)
            {
                map_arr[enemy_head_pos_y_set[i]][enemy_head_pos_x_set[i]] = EMPTY;
            }
            enemy_head_pos_x_set.clear();
            enemy_head_pos_y_set.clear();

            break;
        }

        if (this->get_hard_mod() == 0) // default.
        {
            int enemy_direction = rand() % 4; // select random move

            if (enemy_direction == UP)
            {
                enemy_head_pos_y += 1;
                if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3) // cant move to there, so select again.
                {
                    enemy_head_pos_y -= 1;
                    continue;
                }
            }
            else if (enemy_direction == DOWN)
            {
                enemy_head_pos_y -= 1;
                if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                {
                    enemy_head_pos_y += 1;
                    continue;
                }
            }
            else if (enemy_direction == LEFT)
            {
                enemy_head_pos_x -= 1;
                if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                {
                    enemy_head_pos_x += 1;
                    continue;
                }
            }
            else if (enemy_direction == RIGHT)
            {
                enemy_head_pos_x += 1;
                if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                {
                    enemy_head_pos_x -= 1;
                    continue;
                }
            }
            break;
        }
        else // ++ additional mode. In hard mode. enemy snake goes to food by simple algorithm, and when enemy eat food. enemy snake's length increase by 1.
        {
            int enemy_x_diff = (food_pos_x - enemy_head_pos_x);
            int enemy_y_diff = (food_pos_y - enemy_head_pos_y);

            if (abs(enemy_x_diff) > abs(enemy_y_diff)) // if x is far from food.
            {
                if (enemy_x_diff > 0) // food is in rightside of enemy
                {
                    enemy_head_pos_x += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x -= 1;
                    }
                    else { break; }
                }
                else // food is in leftside of enemy
                {
                    enemy_head_pos_x -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x += 1;
                    }
                    else { break; }
                }

                if (enemy_y_diff > 0) // food is in upside of enemy
                {
                    enemy_head_pos_y -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y += 1;
                    }
                    else { break; }
                }
                else // food is in downside of enemy.
                {
                    enemy_head_pos_y += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y -= 1;
                    }
                    else { break; }
                }
                // cant go to food directly. So enemy choose to second best selection.
                if (enemy_y_diff > 0) // same as above.
                {
                    enemy_head_pos_y += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y -= 1;
                    }
                    else { break; }
                }
                else
                {
                    enemy_head_pos_y -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y += 1;
                    }
                    else { break; }
                }

                if (enemy_x_diff > 0)
                {
                    enemy_head_pos_x -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x += 1;
                    }
                    else { break; }
                }
                else
                {
                    enemy_head_pos_x += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x -= 1;
                    }
                    else { break; }
                }
            }
            else // if y is far from food. 
            {
                if (enemy_y_diff > 0)
                {
                    enemy_head_pos_y += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y -= 1;
                    }
                    else { break; }
                }
                else
                {
                    enemy_head_pos_y -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y += 1;
                    }
                    else { break; }
                }

                if (enemy_x_diff > 0)
                {
                    enemy_head_pos_x += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x -= 1;
                    }
                    else { break; }
                }
                else
                {
                    enemy_head_pos_x -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x += 1;
                    }
                    else { break; }
                }

                if (enemy_x_diff > 0)
                {
                    enemy_head_pos_x -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x += 1;
                    }
                    else { break; }
                }
                else
                {
                    enemy_head_pos_x += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_x -= 1;
                    }
                    else { break; }
                }

                if (enemy_y_diff > 0)
                {
                    enemy_head_pos_y -= 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y += 1;
                    }
                    else { break; }
                }
                else
                {
                    enemy_head_pos_y += 1;
                    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] >= 3)
                    {
                        enemy_head_pos_y -= 1;
                    }
                    else { break; }
                }
            }
            while (1) // error case
            {
                enemy_head_pos_x = rand_x(mersenne);
                enemy_head_pos_y = rand_y(mersenne);

                if (map_arr[enemy_head_pos_y][enemy_head_pos_x] == EMPTY)
                {
                    map_arr[enemy_head_pos_y][enemy_head_pos_x] = ENEMY;
                    break;
                }
            }

            for (int i = 0; i < enemy_head_pos_x_set.size(); i++)
            {
                map_arr[enemy_head_pos_y_set[i]][enemy_head_pos_x_set[i]] = EMPTY;
            }
            enemy_head_pos_x_set.clear();
            enemy_head_pos_y_set.clear();

            break;
        }
    }

    if (map_arr[enemy_head_pos_y][enemy_head_pos_x] == FOOD) { // in hard mode, if enemy get food, it's length grows by 1.
        this->set_enemy_snake_length(this->get_enemy_snake_length() + 1);

        while (1)
        {
            food_pos_x = rand_x(mersenne);
            food_pos_y = rand_y(mersenne);

            if (map_arr[food_pos_y][food_pos_x] == EMPTY)
            {
                map_arr[food_pos_y][food_pos_x] = FOOD;
                break;
            }
        }
    }

    map_arr[enemy_head_pos_y][enemy_head_pos_x] = ENEMY;

    enemy_head_pos_x_set.push_back(enemy_head_pos_x); // add to enemy_pos array.
    enemy_head_pos_y_set.push_back(enemy_head_pos_y);

    if (this->get_enemy_snake_length() < enemy_head_pos_x_set.size()) // remove the tails of enemy snake.
    {
        int tail_x = enemy_head_pos_x_set.front();
        int tail_y = enemy_head_pos_y_set.front();
        map_arr[tail_y][tail_x] = EMPTY;
        enemy_head_pos_x_set.pop_front();
        enemy_head_pos_y_set.pop_front();
    }

    print_map();

    return 0;
}

int Map::get_coin_score() // return score.
{
    return this->coin_score;
}

bool Map::is_movable(int x, int y) // judge if object is movable.
{
    return (map_arr[y][x + 1] <= 3) or (map_arr[y][x - 1] <= 3) or (map_arr[y + 1][x] <= 3) or (map_arr[y - 1][x] <= 3);
}