#ifndef UTILS_H
#define UTILS_H

#include "Setting.h"

int start_game(Setting* setting);
void print_MainMenu();
void print_SettingMenu();
void print_end_game(int total_time, int coin_score);

#endif