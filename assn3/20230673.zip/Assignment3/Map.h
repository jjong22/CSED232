#ifndef MAP_H
#define MAP_H

#include <vector>
#include <deque>

using namespace std;

class Map : Setting
{
private:
    int map_arr[100][100] = { 0, };

    int player_snake_length;
    int player_max_life_count;

    vector<int> coin_pos_x_set;
    vector<int> coin_pos_y_set;

    int coin_score;

    int food_pos_x;
    int food_pos_y;

    int player_head_pos_x;
    int player_head_pos_y;
    deque<int> player_pos_x_set;
    deque<int> player_pos_y_set;

    int enemy_head_pos_x;
    int enemy_head_pos_y;
    deque<int> enemy_head_pos_x_set;
    deque<int> enemy_head_pos_y_set;

    enum object { EMPTY = 0, FOOD = 1, COIN = 2, PLAYER = 3, ENEMY = 4, WALL = 5 };

public:
    Map(Setting& setting);
    void print_map();
    int update_map(int user_input);
    int get_coin_score();
    bool is_movable(int x, int y);
};

#endif