#include "mainwindow.h"
#include "startgame.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    StartWindow w;

    w.show(); // show start window
    return a.exec();
}
