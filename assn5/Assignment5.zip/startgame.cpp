#include "startgame.h"
#include "mainwindow.h"
#include <QPixmap>
#include <QLayout>

StartWindow::StartWindow(QWidget *parent) : QWidget(parent) {
    setWindowTitle("20230673");
    setFixedSize(400, 400);

    QVBoxLayout *layout = new QVBoxLayout(this);

    QLabel *label = new QLabel("Snake Game!", this);
    label->setAlignment(Qt::AlignCenter);
    label->setStyleSheet("font-size: 20px;");
    layout->addWidget(label);
    // Start window widget

    /*
    QLabel* eventImg = new QLabel(this);
    // pixmap image load
    QPixmap pm("C:\\Users\\jjong\\OneDrive\\바탕 화면\\객체\\assn5\\Assignment5\\jjong22.jpg"); // <- path to image file
    eventImg->setPixmap(pm);
    eventImg->setScaledContents(true);
    layout->addWidget(eventImg);

    // not worked ;(
    */

    QPushButton *startButton = new QPushButton("Start", this);
    startButton->setStyleSheet("font-size: 16px; padding: 10px;");
    layout->addWidget(startButton);
    //start button

    QPushButton *exitButton = new QPushButton("Exit", this);
    exitButton->setStyleSheet("font-size: 16px; padding: 10px;");
    layout->addWidget(exitButton);
    //end button

    connect(startButton, &QPushButton::clicked, this, &StartWindow::openGameWindow);
    connect(exitButton, &QPushButton::clicked, this, exit);
}
StartWindow::~StartWindow()
{
    ;
}

void StartWindow::openGameWindow() {
    MainWindow *gameWindow = new MainWindow();
    gameWindow->show(); // goto main window

    close();
}
