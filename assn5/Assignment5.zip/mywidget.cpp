#include <QtGui>
#include "mywidget.h"

MyWidget::MyWidget()
{
    setFixedSize(500,200);

    static QIcon Img(QPixmap("./images/icon.png"));


    /* fileMenu라는 최상위 메뉴에 하위 메뉴를 등록하기 위한 코드이다.*/

    fileMenu = menuBar()->addMenu(tr("&File"));
    // 창에 메뉴를 등록하려면 addMenu() 멤버 함수를 사용해야 한다.
    // &File 이라는 파라미터는 메뉴의 제목을 표기해야 하며
    // &는 문자의 단축키를 의미한다.


    newAct = new QAction(Img, tr("&New"), this);
    // QAction 위젯을 사용하여 선언.
    // 첫 번째 파라미터 Img : 이미지 아이콘
    // 두 번째 파라미터 tr() : 이 메뉴의 제목
    // 세 번째 파라미터 this : QObject를 명시


    newAct->setShortcut(tr("Ctrl+N"));
    // 단축키 지정
    // ctrl과 N을 같이 누르면 이 메뉴의 이벤트가 발생한다.


    newAct->setStatusTip(tr("Create a new file"));
    // 창의 아래쪽에 있는 Status Bar 부분에 이 메뉴의 이벤트가 발생했을 때
    // 첫 번째 파라미터의 텍스트를 표기한다.


    connect(newAct, SIGNAL(triggered()), this, SLOT(newFile()));
    // 이 메뉴의 이벤트가 발생했을 때 newFile() 슬롯 함수를 호출하는 코드.


    exitAct = new QAction(tr("Exit"),this);
    exitAct->setShortcut(tr("Ctrl+Q"));
    exitAct->setStatusTip(tr("Exit the application"));
    connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));

    fileMenu->addAction(newAct);
    // fileMenu라는 상위 메뉴에 newAct라는 하위 메뉴를 포함시키기 위한 코드.

    fileMenu->addSeparator();
    // 각 메뉴 사이에 경계선이 필요한 경우 사용하는 함수

    fileMenu->addAction(exitAct);
    // 메뉴를 등록할 때 등록한 순서대로 메뉴가 표기되므로 등록 순서에 주의한다.

    statusBar()->showMessage(tr("A context menu is available by right-clicking"));
    // 창의 아래쪽에 있는 StatusBar에 파라미터의 텍스트를 출력하기 위해 사용.

    setWindowTitle(tr("Menus"));
    // 창의 제목 표시줄에 제목을 설정하기 위해.
}

void MyWidget::newFile()
{
    qDebug("newFile Menu Action");
}

/* 마우스 오른쪽 버튼을 클릭했을 때 발생하는 이벤트로,
    Context 메뉴를 사용하기 위한 함수*/
void MyWidget::contextMenuEvent(QContextMenuEvent *event)
{
    // 창에서 마우스 오른쪽 버튼을 클릭하면 앞의 함수가 호출되어
    // Context 메뉴를 화면에 출력하고 addAction()함수에 등록된 하위메뉴 항목이 출력된다.
    QMenu menu(this);
    menu.addAction(newAct);
    menu.exec(event->globalPos());
}
