#include "widget.h"
#include <QMenuBar>
#include <QMessageBox>

Widget::Widget(MainWindow *parent) {
    QMenuBar *menuBar = new QMenuBar(this);

    QMenu *fileMenu = new QMenu("Menu", this);
    menuBar->addMenu(fileMenu);

    QAction *stopAction = new QAction("Stop", this);
    fileMenu->addAction(stopAction);

    connect(stopAction, &QAction::triggered, this, &Widget::onStopClicked);

    setMenuBar(menuBar);
}

void Widget::onStopClicked() {
    // Stop 메뉴 클릭 시 동작
    QMessageBox::information(this, "Stop", "Stopping the process!");
    // 실제 Stop 동작 구현 필요
}

Widget::~Widget()
{

}
