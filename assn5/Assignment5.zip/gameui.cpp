#include "gameui.h"

class GameUi : public QWidget
{
    Q_OBJECT
public:

};
