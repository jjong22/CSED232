#ifndef GAME_H
#define GAME_H

#include <QMainWindow>
#include <QWidget>
#include <QTimer>
#include <QList>
#include <QPoint>
#include <QKeyEvent>
#include <QRandomGenerator>
#include <QLabel>

class Game : public QWidget
{
private:
    QTimer *timer;
    QList<QPoint> snake;
    QList<QPoint> enemy_snake;
    QList<QPoint> coin;
    QList<QPoint> food;
    // enemy snake and food's size is allways 1. But I used QList for polymorphism.

    int player_life;
    int score;
    int is_timer;

    int dx;                  // x direction offset
    int dy;                  // y direction offset

    int e_dx;
    int e_dy;

protected:
    void paintEvent(QPaintEvent *event);
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void moveSnake();

public:
    explicit Game();
    ~Game();
    bool isNotMovable(int x, int y);
    bool isThisDirectionNotMovable(int move, int x, int y);
    bool isThisDirectionSnakeNotMovable(int move, int x, int y);
    int return_life();
    int return_score();
    void stop_timer();

signals:
    void scoreChanged(int newScore);
    void lifeChanged(int newLife);
};

#endif // GAME_H
