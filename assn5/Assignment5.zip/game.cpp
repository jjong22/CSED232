#include "game.h"
#include "mainwindow.h"
#include <QApplication>
#include <QPainter>
#include <QTimer>
#include <QDebug>
#include <QKeyEvent>
#include <QRandomGenerator>
#include <QLabel>
#include <QVBoxLayout>

Game::Game() {
    setFocusPolicy(Qt::StrongFocus);
    setFocus();
    setFixedSize(600, 600);

    int x, y;
    dx = 0; dy = 0; e_dx = 0; e_dy = 0;
    score = 0; player_life = 3;
    is_timer = 1;

    // snake
    x = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
    y = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
    snake.push_back(QPoint(x, y));

    while(1) // enemy
    {
        x = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
        y = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)

        // search if location is same with player
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y);
        });
        if (it == snake.end())
            break;
    }
    enemy_snake.push_back(QPoint(x, y));

    for (int i = 0; i < 10; i++)
    {
        while(1) // coin
        {
            x = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
            y = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)

            auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
                return (segment.x() == x && segment.y() == y);
            });
            if (it != snake.end())
                continue;

            it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
                return (segment.x() == x && segment.y() == y);
            });
            if (it != enemy_snake.end())
                continue;

            it = std::find_if(coin.begin(), coin.end(), [&](const QPoint &segment) {
                return (segment.x() == x && segment.y() == y);
            });
            if (it == coin.end())
                break;
        }
        coin.push_back(QPoint(x, y));
    }

    while(1) // food
    {
        x = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
        y = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)

        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y);
        });
        if (it != snake.end())
            continue;

        it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y);
        });
        if (it != enemy_snake.end())
            continue;

        it = std::find_if(coin.begin(), coin.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y);
        });
        if (it == coin.end())
            break;
    }
    food.push_back(QPoint(x, y));

    // setting every item without overlaping.

    // set up the timer to move the snake every 200ms
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Game::moveSnake);
    timer->start(200); // Timer triggers moveSnake() every 200ms
}

Game::~Game() {}


void Game::paintEvent(QPaintEvent *event) // paint map
{
    QPainter painter(this);
    painter.setBrush(Qt::blue);

    // draw the snake as a series of blue circles with radius 10 (player)
    for (const QPoint &segment : snake) {
        painter.drawEllipse(segment, 10, 10);
    }

    painter.setBrush(Qt::red);
    // draw the snake as a series of red circles with radius 10 (enemy)
    for (const QPoint &segment : enemy_snake) {
        painter.drawEllipse(segment, 10, 10);
    }

    painter.setBrush(Qt::yellow);
    // draw the coin as a series of yello square with radius 10 (coin)
    for (const QPoint &segment : coin) {
        painter.drawRect(segment.x()-5, segment.y()-5, 10, 10);
    }

    painter.setBrush(Qt::black);
    // draw the food as a series of black square with radius 10 (food)
    for (const QPoint &segment : food) {
        painter.drawRect(segment.x()-5, segment.y()-5, 10, 10);
    }
}

void Game::keyPressEvent(QKeyEvent *event){ // event process with player's snake.
    // compute a new head position
    int move;
    int dead = 0;

    switch (event->key()) {
    case Qt::Key_W: dx = 0; dy = -20; move = 2; break;
    case Qt::Key_S: dx = 0; dy = +20; move = 3; break;
    case Qt::Key_A: dx = -20; dy = 0; move = 0; break;
    case Qt::Key_D: dx = +20; dy = 0; move = 1;break;
    default: break;
    }

    QPoint pre_newHead = snake.front() + QPoint(dx, dy);
    QPoint newHead = pre_newHead;

    // qDebug() << "Y Position:" << pre_newHead.y();
    // qDebug() << "X Position:" << pre_newHead.x();

    if (isThisDirectionNotMovable(move, pre_newHead.x(), pre_newHead.y())) // screen wall or snake itself.
        dead = 1;
    if (isThisDirectionSnakeNotMovable(move, pre_newHead.x(), pre_newHead.y())) // enemy snake.
        dead = 1;

    // qDebug() << "is dead?" << dead;

    if (dead == 1)
    {
        snake.clear();

        player_life -= 1;

        int new_x = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
        int new_y = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ;

        newHead = QPoint(new_x, new_y);

        snake.push_back(newHead);

        return ;
    }

    snake.push_front(newHead); // add a new head

    auto it = std::find_if(food.begin(), food.end(), [&](const QPoint &segment) { // if food
        return segment.x() == newHead.x() && segment.y() == newHead.y();
    });

    if (it != food.end()) { // if food
        int x, y;
        while(1)
        {
            food.erase(it);
            // set food random place again.

            x = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)
            y = ( QRandomGenerator::global()->bounded(29) * 20 ) + 20 ; // (20 ~ 580)

            auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
                return (segment.x() == x && segment.y() == y);
            });
            if (it != snake.end())
                continue;

            it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
                return (segment.x() == x && segment.y() == y);
            });
            if (it != enemy_snake.end())
                continue;

            it = std::find_if(coin.begin(), coin.end(), [&](const QPoint &segment) {
                return (segment.x() == x && segment.y() == y);
            });
            if (it == coin.end())
                break;
        }
        food.clear();
        food.push_back(QPoint(x, y));
        return ;

    } else {
        ;
    }

    it = std::find_if(coin.begin(), coin.end(), [&](const QPoint &segment) { // if coin
        return segment.x() == newHead.x() && segment.y() == newHead.y();
    });

    if (it != coin.end()) {
        coin.erase(it);
        score += 1;
    } else {
        ;
    }

    snake.pop_back();
}

void Game::moveSnake() // update enemy snake's location.
{
    if (!this->is_timer) return ;
    qDebug() << "is timer:" << is_timer;

    QPoint pre_newHead = enemy_snake.front() + QPoint(e_dx, e_dy);
    QPoint newHead = pre_newHead;

    if ( isNotMovable(pre_newHead.x(), pre_newHead.y()) )
        return ;

    int move;

    while(1)
    {
        move = QRandomGenerator::global()->bounded(4);

        switch (move) {
        case 0: e_dx = -20; e_dy = 0; break;
        case 1: e_dx = +20; e_dy = 0; break;
        case 2: e_dx = 0; e_dy = -20; break;
        case 3: e_dx = 0; e_dy = +20; break;
        default: break;
        }

        if (!isThisDirectionNotMovable(move, pre_newHead.x() + e_dx, pre_newHead.y() + e_dy))
            break;
        // if (!isThisDirectionSnakeNotMovable(move, pre_newHead.x(), pre_newHead.y())) break;
        // enemy snake's length is 1, so we don't need to care of this.
    }

    enemy_snake.push_front(newHead); // add a new head
    enemy_snake.pop_back();          // remove a tail

    update(); // refresh the window to reflect the updated snake position
}

bool Game::isThisDirectionNotMovable(int move, int x, int y) // it can't move in enemy snake's perspect.
{
    int margin = 20;
    bool not_left = 0;
    bool not_right = 0;
    bool not_up = 0;
    bool not_down = 0;

    if (x - margin < 0) not_left = 1; // it is wall
    else { // there is player snake in left side.
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x - margin && segment.y() == y);
        });
        if (it != snake.end())
            not_left = 1;
    }
    if (x + margin > 600) not_right = 1; // ...
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x + margin && segment.y() == y);
        });
        if (it != snake.end())
            not_right = 1;
    }
    if (y - margin < 0) not_up = 1;
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y - margin);
        });
        if (it != snake.end())
            not_up = 1;
    }
    if (y + margin > 600) not_down = 1;
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y + margin);
        });
        if (it != snake.end())
            not_down = 1;
    }
    // qDebug() << not_left << not_right << not_up << not_down;
    // qDebug() << "random Move:" << move;

    if (move == 0) return not_left;
    else if (move == 1) return not_right;
    else if (move == 2) return not_up;
    else if (move == 3) return not_down;
}

bool Game::isNotMovable(int x, int y) // is enemy snake cant move?
{
    int margin = 20;
    bool not_left, not_right, not_up, not_down;

    if (x - margin < 0) not_left = 1;
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x - margin && segment.y() == y);
        });
        if (it != snake.end())
            not_left = 1;
    }
    if (x + margin > 600) not_right = 1;
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x + margin && segment.y() == y);
        });
        if (it != snake.end())
            not_right = 1;
    }
    if (y - margin < 0) not_up = 1;
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y - margin);
        });
        if (it != snake.end())
            not_up = 1;
    }
    if (y + margin > 600) not_down = 1;
    else {
        auto it = std::find_if(snake.begin(), snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y + margin);
        });
        if (it != snake.end())
            not_down = 1;
    }

    return not_left & not_right & not_up & not_down; // all dirction is impossible.
}

bool Game::isThisDirectionSnakeNotMovable(int move, int x, int y) // it can't move in enemy snake's perspect.
{
    int margin = 20;
    bool not_left = 0;
    bool not_right = 0;
    bool not_up = 0;
    bool not_down = 0;

    if (x - margin < 0) not_left = 1; // left side is wall.
    else { // there is enemy snake in left side.
        auto it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x - margin && segment.y() == y);
        });
        if (it != enemy_snake.end())
            not_left = 1;
    }
    if (x + margin > 600) not_right = 1;
    else {
        auto it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x + margin && segment.y() == y);
        });
        if (it != enemy_snake.end())
            not_right = 1;
    }
    if (y - margin < 0) not_up = 1;
    else {
        auto it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y - margin);
        });
        if (it != enemy_snake.end())
            not_up = 1;
    }
    if (y + margin > 600) not_down = 1;
    else {
        auto it = std::find_if(enemy_snake.begin(), enemy_snake.end(), [&](const QPoint &segment) {
            return (segment.x() == x && segment.y() == y + margin);
        });
        if (it != enemy_snake.end())
            not_down = 1;
    }

    if (move == 0) return not_left;
    else if (move == 1) return not_right;
    else if (move == 2) return not_up;
    else if (move == 3) return not_down;
}

int Game::return_life()
{
    return this->player_life;
}
int Game::return_score()
{
    return this->score;
}

void Game::stop_timer()
{
    this->is_timer = 0;
}
