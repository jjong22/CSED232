#include "status.h"
#include "mainwindow.h"

status::status(QWidget *parent) : QWidget(parent) {

}
status::~status()
{
    const int main_window_width = 600;
    const int main_window_height = 200;

    resize(main_window_width, main_window_height);

    QLabel *status_label = new QLabel("게임 준비 중", this);
    statusBar()->addWidget(status_label);

    QLabel *right_status = new QLabel("플레이어: 1", this);
    statusBar()->addPermanentWidget(right_status);
}
