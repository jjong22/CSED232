#ifndef GAMEUI_H
#define GAMEUI_H

#include <QWidget>

class Gameui : public QWidget
{
    Q_OBJECT
public:
    Gameui();
    ~Gameui();
protected:
    void keyPressEvent(QKeyEvent*) override;

public slots:

};

#endif // GAMEUI_H
