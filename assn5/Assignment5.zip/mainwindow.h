#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "game.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void update_status(int life, int score, QTimer *timer);

private:
    int life;
    int score;
    void setup_ui();
    void end_game();

    Game* game;
};

#endif // MAINWINDOW_H
