#include "mainwindow.h"
#include "game.h"
#include <QMainWindow>
#include <QStatusBar>
#include <QPainter>
#include <QTimer>
#include <QDebug>
#include <QKeyEvent>
#include <QRandomGenerator>
#include <QLabel>
#include <QMessageBox>
#include <QMenuBar>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    this->life = 3;
    this->score = 0;

    game = new Game();
    // make game widget
    setup_ui();
}

MainWindow::~MainWindow() {}

void MainWindow::update_status(int life, int score, QTimer *timer)
{
    this->life = life;
    this->score = score;
    // the information from game class, update the value of mainwindow class.

    statusBar()->showMessage("score : " + QString::number(score) + "  life : " + QString::number(life));
    // update statusbar

    if (life == 0) // if game is ended
    {
        timer->stop();
        end_game();
    }
}

void MainWindow::end_game()
{
    QMessageBox msgBox;
    MainWindow *gameWindow = nullptr;

    game->stop_timer();
    // stop enemy's move

    msgBox.setWindowTitle("Game Over");
    msgBox.setText("Score : " + QString::number(score));
    msgBox.setStandardButtons(QMessageBox::Reset | QMessageBox::Close);
    int ret = msgBox.exec();

    life = 3;
    score = 0;

    switch (ret) {
    case QMessageBox::Reset: // restart button
        gameWindow = new MainWindow();
        gameWindow->show();

        close();
        break;
    case QMessageBox::Close : // close button
        exit(0);
        break;
    }
}


void MainWindow::setup_ui()
{
    const int main_window_width = 600;
    const int main_window_height = 600;

    // menu bar
    QMenuBar *menu_bar = menuBar();
    menu_bar->setStyleSheet("background-color: lightgray;");
    QMenu *file_menu = menu_bar->addMenu("Menu");
    QAction *exit_action = file_menu->addAction("Stop");
    connect(exit_action, &QAction::triggered, this, &MainWindow::end_game);

    // main game window
    resize(main_window_width, main_window_height);
    setCentralWidget(game);

    // status bar
    statusBar()->showMessage("score : " + QString::number(score) + "  life : " + QString::number(life));
    statusBar()->setStyleSheet("background-color: lightgray;");

    show();

    // update status with timer. We used lambda function for function pointer.
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, [this, timer]() {
        update_status(game->return_life(), game->return_score(), timer);
    });
    timer->start(200); // Timer triggers moveSnake() every 200ms

    return;
}

