#ifndef WIDGET_H
#define WIDGET_H

#include "mainwindow.h"

class Widget : public MainWindow
{
public:
    Widget(MainWindow *parent = nullptr);
    ~Widget();
private:
    void onStopClicked();
};

#endif // WIDGET_H
