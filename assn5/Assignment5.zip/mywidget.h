#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QMainWindow>

class QAction;
class QActionGroup;
class QLabel;
class QMenu;
class QHBoxLayout;

class MyWidget : public QMainWindow
{
    Q_OBJECT

public :
    MyWidget();

protected :
    void contextMenuEvent(QContextMenuEvent *event);

private :
    // QMenu 위젯으로 메뉴를 사용하기 위함.
    // fileMenu를 선언한 후
    // 이 메뉴의 하위 메뉴를 QAction위젯을 이용해 등록한다.
    QMenu *fileMenu;

    QAction *newAct;
    QAction *exitAct;

    QHBoxLayout *layout;

private slots :
    void newFile();
};

#endif // MYWIDGET_H
